/* global bootbox */

var htmlHeader = {
    prefix: '/icxdesk',
    headers: {
        'Accept': 'text/html',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Ico-Requested': 'true',
        'accessToken': window.localStorage.getItem("access_token") ? window.localStorage.getItem("access_token") : ''
    }
};
var Ajax = {
    get: function (url, data, div, callBack) {
        $.ajax({
            url: url,
            headers: htmlHeader.headers,
            cache: false,
            data: data,
            type: 'get',
            async: true,
//            beforeSend: function () {
//               $(".modal_overlays").show();
//            },
//            complete: function () {
//                $(".modal_overlays").hide();
//            },
            success: function (data) {
                $("#" + div).html(data);
                if (callBack !== undefined && callBack !== null)
                    callBack();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
                if (jqXHR.status === 401)
                {
                    bootbox.alert({
                        message: "Sorry! Your session has been expired.",
                        buttons: {
                            ok: {
                                className: 'btn btn-primary btn-sm'
                            }
                        },
                        callback: function (result)
                        {
                            window.location = "login.htm";
                        }
                    });
                }
                else if (jqXHR.status === 403)
                {
                    bootbox.alert({
                        message: "Sorry! You don't have access permissions for that.",
                        buttons: {
                            ok: {
                                className: 'btn btn-primary btn-sm'
                            }
                        }
                    });
                }
            }
        });
    },
    post: function (url, data, div, callBack) {
        $.ajax({
            url: url,
            headers: htmlHeader.headers,
            cache: false,
            data: data,
            type: 'post',
            async: true,
//            beforeSend: function () {
//               $(".modal_overlays").show();
//            },
//            complete: function () {
//                $(".modal_overlays").hide();
//            },
            success: function (data) {
                $("#" + div).html(data);
                if (callBack !== undefined && callBack !== null)
                    callBack();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
                if (jqXHR.status === 401)
                {
                    bootbox.alert({
                        message: "Sorry! Your session has been expired.",
                        buttons: {
                            ok: {
                                className: 'btn btn-primary btn-sm'
                            }
                        },
                        callback: function (result)
                        {
                            window.location = "login.htm";
                        }
                    });
                }
                else if (jqXHR.status === 403)
                {
                    bootbox.alert({
                        message: "Sorry! You don't have access permissions for that.",
                        buttons: {
                            ok: {
                                className: 'btn btn-primary btn-sm'
                            }
                        }
                    });
                }
            }
        });
    }
};