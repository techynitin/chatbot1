/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var stompClient = null;

$(function () {
    $("#frmChatbot").on('submit', function (e) {
        e.preventDefault();
    });
    connect();
});

function connect() {
    var socket = new SockJS('/HackChatbot/ws');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, onConnected, onError);
}

function onConnected() {
    // Subscribe to the Public Topic
    console.log("connected !!");
    stompClient.subscribe('/topic/chatresponse', onMessageReceived);
}

function onError(error) {
    console.log(error);
}

function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);
    $("#chatCon").append("<div class='chat-system'><div style='float:left;'><div class='text-info'>"+message.user+"</div><div>"+message.content+"</div></div></div><div class='divider'></div>");
}

function sendMessage() {
    var messageContent = $("#txtQuery").val();
    $("#chatCon").append("<div class='chat-user'><div style='float:right;'><div class='text-info'>Anonymous</div><div>"+messageContent+"</div></div></div><div class='divider'></div>");
    //Ajax.post("usermaster.htm?action=report", $('form[name=frmFilter]').serialize(), "divReport", loadDataTable);
//    Ajax.post("chatresponse",messageContent,"divResult",null);
//    var resp = ($("#hdnResult").val() === undefined) ? 'Sorry, ask again.' : $("#hdnResult").val();
//    $("#chatCon").append("<div class='chat-user'><div style='float:right;'><div class='text-info'>Anonymous</div><div>"+resp+"</div></div></div><div class='divider'></div>");
//    $("#txtQuery").val("");
    
    if(messageContent && stompClient) {
        var chatMessage = {
            user: "Bot",
            content: $("#txtQuery").val()
        };
        stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
        $("#txtQuery").val("");
    }
}