/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.hackchatbot.controller;

import com.finlogic.hackchatbot.model.ChatMessage;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.CustomsearchRequestInitializer;
import com.google.api.services.customsearch.model.Result;
import com.google.api.services.customsearch.model.Search;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

/**
 *
 * @author Nitin Chauhan
 */

@Controller
public class ChatController
{
    private String apiResponse(String request)
    {
        String response = "Sorry, ask again.";
        try {
            String searchQuery = request; //The query to search
            String cx = "003660872324968077175:n60s103so4k"; //Your search engine

            //Instance Customsearch
            Customsearch cs = new Customsearch.Builder(GoogleNetHttpTransport.newTrustedTransport(), JacksonFactory.getDefaultInstance(), null) 
                           .setApplicationName("MyApplication") 
                           .setGoogleClientRequestInitializer(new CustomsearchRequestInitializer("AIzaSyD2K2Rahm0qC_NvPqeaGVaAP34cxMxf9dE")) //key
                           .build();

            //Set search parameter
            Customsearch.Cse.List list = cs.cse().list(searchQuery).setCx(cx); 

            StringBuilder sb = new StringBuilder();
            //Execute search
            Search result = list.execute();
            int count = 0;
            if (result.getItems()!=null) {
                for (Result ri : result.getItems()) {
                    //Get title, link, body etc. from search
                    System.out.println("result => "+ri.getTitle());
                    if(count == 3)
                        break;
                    sb.append(ri.getTitle()).append("<br>");
                    count++;
                }
            }
            response =  sb.toString();
        }
        catch(Exception e) {
            response = "Sorry, ask again.";
        }
        return response;
    }
    
    @MessageMapping(value = "/chat.sendMessage")
    @SendTo(value = "/topic/chatresponse")
    public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
        chatMessage.setContent(apiResponse(chatMessage.getContent()));
        return chatMessage;
    }
}