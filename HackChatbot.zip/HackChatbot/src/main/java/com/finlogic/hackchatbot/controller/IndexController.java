/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.hackchatbot.controller;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.CustomsearchRequestInitializer;
import com.google.api.services.customsearch.model.Result;
import com.google.api.services.customsearch.model.Search;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author Nitin Chauhan
 */

@Controller
public class IndexController
{
    @GetMapping(value="/")
    public String home(ModelMap model)
    {
        return "index";
    }
 
    @PostMapping(value="/chatresponse")
    public String chatResponse(ModelMap model)
    {
        try {
            String searchQuery = "cat"; //The query to search
            String cx = "003660872324968077175:n60s103so4k"; //Your search engine

            //Instance Customsearch
            Customsearch cs = new Customsearch.Builder(GoogleNetHttpTransport.newTrustedTransport(), JacksonFactory.getDefaultInstance(), null) 
                           .setApplicationName("MyApplication") 
                           .setGoogleClientRequestInitializer(new CustomsearchRequestInitializer("AIzaSyD2K2Rahm0qC_NvPqeaGVaAP34cxMxf9dE")) //key
                           .build();

            //Set search parameter
            Customsearch.Cse.List list = cs.cse().list(searchQuery).setCx(cx); 

            StringBuilder sb = new StringBuilder();
            //Execute search
            Search result = list.execute();
            int count = 0;
            if (result.getItems()!=null) {
                for (Result ri : result.getItems()) {
                    //Get title, link, body etc. from search
                    if(count == 3)
                        break;
                    sb.append(ri.getTitle()).append("<br>");
                    count++;
                }
            }
            model.addAttribute("result", sb.toString());
        }
        catch(Exception e) {
            model.addAttribute("result","Sorry, ask vsd again.");
        }
        return "ajax";
    }
}